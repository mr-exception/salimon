# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: optical.spec.ts >> OPT-3 near/far physical depths and huge-origin telescope preserve optical pixels
- Location: tests/optical.spec.ts:65:1

# Error details

```
Test timeout of 120000ms exceeded.
```

# Page snapshot

```yaml
- button "Pulse" [ref=f4e7]
```