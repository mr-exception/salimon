# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: panoramic-captures.spec.ts >> PANO-VIS panoramic optical, sensor, actions and HUD reference matrix
- Location: tests/panoramic-captures.spec.ts:17:1

# Error details

```
Error: PANORAMIC_PIXEL_MISMATCH telescope

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- region "Panoramic navigation" [ref=f8e3]:
  - generic "Panoramic universe" [active] [ref=f8e6]
  - generic [aria-hidden]: +
  - generic:
    - strong: SALIMON · OBSERVATION
    - status: Scanner pulse 1 · 40 contacts
    - generic: destroyed · 200.0 m/s · sample inertial frame
  - status "Navigation warnings":
    - paragraph: Journey ended — ship destroyed · impact 200.0 m/s
    - button "Restart navigation" [ref=f8e7] [cursor=pointer]
  - generic:
    - button "Sensor contact Contact 00" [ref=f8e8] [cursor=pointer]: +
    - button "Sensor contact Contact 01" [ref=f8e9] [cursor=pointer]: +
    - button "Sensor contact Contact 02" [ref=f8e10] [cursor=pointer]: +
    - region "Detected contacts" [ref=f8e11]:
      - button "Contacts (C) · 40" [expanded] [ref=f8e12] [cursor=pointer]
      - generic [ref=f8e13]:
        - generic [ref=f8e14]:
          - text: Search contacts
          - textbox "Search contacts" [ref=f8e15]
        - list [ref=f8e16]:
          - listitem [ref=f8e17]:
            - button "Contact 00" [ref=f8e18] [cursor=pointer]
          - listitem [ref=f8e19]:
            - button "Contact 01" [ref=f8e20] [cursor=pointer]
          - listitem [ref=f8e21]:
            - button "Contact 10" [ref=f8e22] [cursor=pointer]
          - listitem [ref=f8e23]:
            - button "Contact 11" [ref=f8e24] [cursor=pointer]
          - listitem [ref=f8e25]:
            - button "Contact 12" [ref=f8e26] [cursor=pointer]
          - listitem [ref=f8e27]:
            - button "Contact 13" [ref=f8e28] [cursor=pointer]
          - listitem [ref=f8e29]:
            - button "Contact 14" [ref=f8e30] [cursor=pointer]
          - listitem [ref=f8e31]:
            - button "Contact 15" [ref=f8e32] [cursor=pointer]
        - button "Previous" [disabled] [ref=f8e33]
        - generic [ref=f8e34]: 1/5
        - button "Next" [ref=f8e35] [cursor=pointer]
      - status [ref=f8e37]: No selection
  - generic:
    - figure "3D orientation compass":
      - 'img "Camera cyan at center. Heading yellow: front, right 0.0, up 0.0, depth 1.00. Velocity green: front, right 0.0, up 0.0, depth 1.00. Solid front, hollow rear."':
        - generic: UP
      - generic:
        - text: Cyan view · Yellow heading
        - emphasis: Green velocity
        - text: · solid front / hollow rear
  - generic [ref=f8e38]:
    - generic [ref=f8e39]:
      - text: Throttle 0%
      - slider "Throttle" [disabled] [ref=f8e40]: "0"
    - button "Zero throttle (Space)" [disabled] [ref=f8e41]
    - button "Reset view" [ref=f8e42] [cursor=pointer]
    - button "Telemetry" [expanded] [ref=f8e43] [cursor=pointer]
    - button "Help" [ref=f8e44] [cursor=pointer]
    - button "Exit cockpit" [ref=f8e45] [cursor=pointer]
  - region "Detailed telemetry" [ref=f8e46]:
    - paragraph [ref=f8e47]: Mass 100,000 kg · FOV 75.00°
    - paragraph [ref=f8e48]: Yaw 0.0° · pitch 0.0° · Manual
    - paragraph [ref=f8e49]: Cell 0 / 0 / 0 · local 0.0 / 5000.0 / -98063.3 m
    - paragraph [ref=f8e50]: Illustrative universe · unlimited energy. Impacts at 100 m/s or faster end the run.
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test'
  2   | import { readFile, writeFile, mkdir } from 'node:fs/promises'
  3   | import { execFileSync } from 'node:child_process'
  4   | import { isAbsolute, resolve, sep } from 'node:path'
  5   | import { compareImages, POLICY, sha256 } from '../scripts/visual-comparison.ts'
  6   | 
  7   | const directory = 'tests/navigation-baselines'
  8   | const candidate = process.env.SALIMON_PANORAMIC_CANDIDATES || undefined
  9   | if (candidate && process.env.CI) throw Error('Candidate generation is forbidden in CI')
  10  | if (candidate && (!isAbsolute(candidate) || resolve(candidate) === resolve(directory) || resolve(candidate).startsWith(resolve(directory) + sep))) throw Error('Use an absolute candidate directory outside tracked references')
  11  | const json = (v: unknown) => JSON.stringify(v, (_, x) => typeof x === 'bigint' ? String(x) : x, 2)
  12  | // Observers are fixture-only, read-only snapshots of the production adapters.
  13  | async function state(page: Page, owner: string): Promise<Record<string, unknown>> {
  14  |  return page.evaluate(owner => (window as unknown as Record<string, () => Record<string, unknown>>)[`${owner}Snapshot`](), owner)
  15  | }
  16  | 
  17  | test('PANO-VIS panoramic optical, sensor, actions and HUD reference matrix', async ({ page, browser }, info) => {
  18  |  test.setTimeout(360000)
  19  |  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message))
  20  |  const source = await readFile('.revision-for-negative', 'utf8').catch(() => execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim())
  21  |  const environment = { platform: process.platform, arch: process.arch, browser: browser.version(), playwright: JSON.parse(await readFile('node_modules/@playwright/test/package.json', 'utf8')).version,
  22  |   viewport: { width: 1280, height: 800 }, dpr: 1, epoch: '2026-11-06T12:00:00.000Z', locale: 'en-US', timezone: 'UTC', policy: POLICY,
  23  |   fonts: Object.fromEntries(await Promise.all(['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf', 'fonts.css', 'fonts.conf'].map(async f => [f, sha256(await readFile(`tests/assets/${f}`))]))) }
  24  |  expect(info.project.use.launchOptions?.env?.FONTCONFIG_FILE).toMatch(/tests\/assets\/fonts\.conf$/)
  25  |  const manifest = JSON.parse(await readFile(`${directory}/manifest.json`, 'utf8'))
  26  |  if (!candidate) expect(environment, 'PANORAMIC_ENVIRONMENT_DRIFT').toEqual(manifest.panoramic.environment)
  27  |  const images: Record<string, string> = {}, results: Record<string, unknown>[] = []
  28  |  const output = candidate ?? info.outputPath('comparisons'); await mkdir(output, { recursive: true })
  29  |  await page.clock.install({ time: new Date(environment.epoch) })
  30  |  await page.clock.pauseAt(new Date('2026-11-06T12:00:01Z'))
  31  |  const settle = async () => { await page.clock.runFor(160) }
  32  |  const boot = async (path: string, owner: string) => {
  33  |   await page.goto(path)
  34  |   await expect.poll(async () => { await settle(); return (await state(page, owner))?.renderer }).toContain('SwiftShader')
  35  |   await page.evaluate(() => document.fonts.ready); await settle()
  36  |  }
  37  |  const capture = async (id: string, owner: string) => {
  38  |   await page.locator('canvas').focus(); await page.mouse.move(1279, 799); await settle()
  39  |   const snapshot = await state(page, owner)
  40  |   const actual = await page.screenshot({ caret: 'hide' }), name = `panoramic-${id}.png`
  41  |   images[name] = sha256(actual)
  42  |   await writeFile(`${output}/${name}`, actual)
  43  |   await writeFile(`${output}/panoramic-${id}.json`, json({ source, environment, viewport: page.viewportSize(), dpr: await page.evaluate(() => window.devicePixelRatio), snapshot, errors }))
  44  |   await info.attach(name, { body: actual, contentType: 'image/png' })
  45  |   if (candidate) { results.push({ id, status: 'CANDIDATE', sha256: images[name] }); return }
  46  |   const expected = await readFile(`${directory}/${name}`)
  47  |   expect(sha256(expected), `PANORAMIC_BASELINE_HASH ${id}`).toBe(manifest.images[name])
  48  |   const { diff, ...comparison } = compareImages(expected, actual)
  49  |   await writeFile(`${output}/${id}-diff.png`, diff)
  50  |   results.push({ id, ...comparison, expected: sha256(expected), actual: images[name] })
> 51  |   expect.soft(comparison.pass, `PANORAMIC_PIXEL_MISMATCH ${id}`).toBe(true)
      |                                                                  ^ Error: PANORAMIC_PIXEL_MISMATCH telescope
  52  |  }
  53  |  for (const scenario of ['wide', 'telescope', 'telescope-translated', 'translated', 'surface', 'below']) {
  54  |   await boot(`/tests/optical.html?scenario=${scenario}`, 'optical')
  55  |   expect((await state(page, 'optical')).contacts).toBe(0)
  56  |   await capture(scenario, 'optical')
  57  |  }
  58  |  await boot('/tests/perspective.html?low-resolution', 'sensor')
  59  |  expect((await state(page, 'sensor')).selected).toBeNull()
  60  |  await capture('empty-scanner', 'sensor')
  61  |  // Adversarial optical clicks must never discover or select catalog bodies.
  62  |  await page.locator('canvas').click({ position: { x: 640, y: 400 } }); await settle()
  63  |  expect((await state(page, 'sensor')).selected, 'OPTICAL_SELECTION_LEAK').toBeNull()
  64  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await settle()
  65  |  const markers = (await state(page, 'sensor')).markers as { ids: string[] }[]
  66  |  expect(markers.flatMap(m => m.ids)).not.toContain('hidden')
  67  |  expect(markers.flatMap(m => m.ids)).not.toContain('back')
  68  |  await expect(page.getByRole('button', { name: 'Sensor contact Detected hidden', exact: true })).toHaveCount(0)
  69  |  await expect(page.getByRole('button', { name: 'Sensor contact Detected back', exact: true })).toHaveCount(0)
  70  |  await capture('detected-occluded-rear', 'sensor')
  71  |  await page.getByRole('button', { name: 'Sensor contact Detected planet', exact: true }).click(); await settle()
  72  |  expect((await state(page, 'sensor')).selected).toBe('planet') // hidden center cannot intercept
  73  |  await page.getByRole('button', { name: 'Sensor contact group of 18', exact: true }).click(); await settle()
  74  |  await capture('overlap', 'sensor')
  75  |  await page.getByRole('button', { name: 'Next', exact: true }).click(); await settle()
  76  |  await capture('pagination', 'sensor')
  77  |  await page.getByRole('button', { name: 'Telescope', exact: true }).click(); await settle()
  78  |  await capture('sensor-telescope', 'sensor')
  79  |  await page.getByRole('button', { name: 'Leave range', exact: true }).click(); await settle()
  80  |  expect((await state(page, 'sensor')).selected).toBeNull()
  81  |  await expect(page.getByRole('button', { name: 'Set direction', exact: true })).toHaveCount(0)
  82  |  await capture('lost-contact', 'sensor')
  83  |  await boot('/tests/look-at.html', 'look')
  84  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await settle()
  85  |  await page.getByRole('textbox').fill('Behind')
  86  |  await page.getByRole('button', { name: 'Behind', exact: true }).click()
  87  |  const before = (await state(page, 'look')).ship
  88  |  await page.getByRole('button', { name: 'Look at', exact: true }).click()
  89  |  await page.clock.runFor(1200)
  90  |  expect((await state(page, 'look')).ship).toEqual(before)
  91  |  await capture('look-at-occluded', 'look')
  92  |  await page.getByRole('button', { name: 'Set direction', exact: true }).click()
  93  |  await page.clock.runFor(320)
  94  |  expect(((await state(page, 'look')).ship as { yaw: number }).yaw).not.toBe((before as { yaw: number }).yaw)
  95  |  await capture('set-direction', 'look')
  96  |  await boot('/tests/panoramic.html', 'hud')
  97  |  await page.evaluate(() => (window as unknown as { hudAdvance(s: number): void }).hudAdvance(5))
  98  |  await settle()
  99  |  expect(((await state(page, 'hud')).contacts as string[]).length).toBe(40)
  100 |  for (const kind of ['stationary', 'rear', 'overlap']) {
  101 |   await page.evaluate(kind => (window as unknown as { hudScenario(k: string): void }).hudScenario(kind), kind)
  102 |   await capture(`compass-${kind}`, 'hud')
  103 |  }
  104 |  await page.setViewportSize({ width: 960, height: 600 })
  105 |  await page.getByRole('button', { name: /Contacts \(C\)/ }).click()
  106 |  await page.getByRole('button', { name: 'Telemetry', exact: true }).click()
  107 |  for (const kind of ['warning', 'destroyed']) {
  108 |   await page.evaluate(kind => (window as unknown as { hudScenario(k: string): void }).hudScenario(kind), kind)
  109 |   await settle()
  110 |   expect(await page.evaluate(() => ({ w: document.documentElement.scrollWidth, h: document.documentElement.scrollHeight }))).toEqual({ w: 960, h: 600 })
  111 |   if (kind === 'warning') await expect(page.getByLabel('Navigation warnings')).not.toBeEmpty()
  112 |   if (kind === 'destroyed') await expect(page.getByRole('button', { name: 'Restart navigation', exact: true })).toBeInViewport()
  113 |   await capture(`small-${kind}`, 'hud')
  114 |  }
  115 |  expect(errors).toEqual([])
  116 |  await writeFile(`${output}/summary.json`, json({ source, environment, candidate, results, errors }))
  117 |  await info.attach('panoramic-summary.json', { body: json({ source, environment, candidate, results, errors }), contentType: 'application/json' })
  118 |  if (candidate) {
  119 |   // A complete proposal retains every other reference family, without editing
  120 |   // the tracked corpus or granting appearance approval.
  121 |   for (const name of Object.keys(manifest.images)) if (!images[name]) await writeFile(`${output}/${name}`, await readFile(`${directory}/${name}`))
  122 |   await writeFile(`${output}/manifest.json`, json({ ...manifest, panoramic: { environment, status: 'AWAITING_HUMAN_REVIEW' }, images: { ...manifest.images, ...images } }) + '\n')
  123 |  }
  124 | })
  125 | 
```