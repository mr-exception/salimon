# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: optical.spec.ts >> OPT-1 optical disks before scanning, repeat, occultation and far origin invariance
- Location: tests/optical.spec.ts:13:1

# Error details

```
Test timeout of 120000ms exceeded.
```

# Page snapshot

```yaml
- button "Pulse" [ref=f3e7]
```