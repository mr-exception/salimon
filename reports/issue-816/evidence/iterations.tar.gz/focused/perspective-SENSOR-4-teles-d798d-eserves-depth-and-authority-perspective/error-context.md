# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: perspective.spec.ts >> SENSOR-4 telescope high-frequency input at huge origin preserves depth and authority
- Location: tests/perspective.spec.ts:132:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic:
      - button "Sensor contact Detected tiny" [ref=e7]: +
      - region "Detected contacts" [ref=e8]:
        - group [ref=e9]:
          - generic "Observation help" [ref=e10]
        - generic [ref=e11]:
          - generic [ref=e12]:
            - text: Search contacts
            - textbox "Search contacts" [ref=e13]
          - list [ref=e14]:
            - listitem [ref=e15]:
              - button "Detected back" [ref=e16]
            - listitem [ref=e17]:
              - button "Detected dense-00" [ref=e18]
            - listitem [ref=e19]:
              - button "Detected dense-01" [ref=e20]
            - listitem [ref=e21]:
              - button "Detected dense-02" [ref=e22]
            - listitem [ref=e23]:
              - button "Detected dense-03" [ref=e24]
            - listitem [ref=e25]:
              - button "Detected dense-04" [ref=e26]
            - listitem [ref=e27]:
              - button "Detected dense-05" [ref=e28]
            - listitem [ref=e29]:
              - button "Detected dense-06" [ref=e30]
          - button "Previous" [disabled] [ref=e31]
          - generic [ref=e32]: 1/3
          - button "Next" [ref=e33]
        - status [ref=e35]: No selection
  - navigation [ref=e36]:
    - button "Tick" [ref=e37]
    - button "Pulse" [ref=e38]
    - button "Leave range" [ref=e39]
    - button "Telescope" [ref=e40]
    - button "Reset view" [ref=e41]
```

# Test source

```ts
  63  |  expect((await state(page)).selected).toBeNull()
  64  |  expect((await state(page)).contacts).toEqual([])
  65  |  expect(errors).toEqual([])
  66  |  await info.attach('measurements.json', { body: JSON.stringify({ scanned, groupIds: ids, evicted: await state(page), errors }, null, 2), contentType: 'application/json' })
  67  | })
  68  | test('SENSOR-2 repeat/translated pixels, telescope motion and stale group suppression', async ({ page }, info) => {
  69  |  await boot(page)
  70  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  71  |  await expect(sceneMarkers(page)).toHaveCount(3)
  72  |  // Blur Pulse so focus decorations cannot differ between captures.
  73  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  74  |  const first = await page.screenshot(), initial = await state(page)
  75  |  expect((await page.screenshot()).equals(first)).toBe(true)
  76  |  await boot(page, true)
  77  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  78  |  await expect(sceneMarkers(page)).toHaveCount(3)
  79  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  80  |  expect((await page.screenshot()).equals(first)).toBe(true)
  81  |  expect((await state(page)).markers).toEqual(initial.markers)
  82  |  await page.getByRole('button', { name: 'Sensor contact group of 18', exact: true }).click()
  83  |  await page.getByRole('button', { name: 'Telescope', exact: true }).click()
  84  |  await expect(page.getByText('Group no longer visible')).toBeVisible()
  85  |  await expect(page.getByRole('region', { name: 'Detected contacts' }).locator('li button')).toHaveCount(0)
  86  |  await page.getByRole('button', { name: 'All contacts', exact: true }).click()
  87  |  await page.getByRole('textbox').fill('back')
  88  |  await page.keyboard.press('KeyD')
  89  |  const focused = (await state(page)).view
  90  |  await page.keyboard.down('KeyD'); await page.waitForTimeout(100); await page.keyboard.up('KeyD')
  91  |  expect((await state(page)).view).toEqual(focused)
  92  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  93  |  await page.keyboard.down('KeyD')
  94  |  const motion = await page.evaluate(async () => {
  95  |   const samples: (State & { domMarkers: number })[] = []
  96  |   for (let i = 0; i < 6; i++) { await new Promise(requestAnimationFrame); samples.push({ ...(window as unknown as { sensorSnapshot(): State }).sensorSnapshot(), domMarkers: document.querySelectorAll('button[aria-label^="Sensor contact "]').length }) }
  97  |   return samples
  98  |  })
  99  |  await page.keyboard.up('KeyD')
  100 |  expect(motion.every(s => s.domMarkers === 1 && s.markers.length === 1 && s.markers.every(m => Number.isFinite(m.x) && Number.isFinite(m.y)))).toBe(true)
  101 |  await expect.poll(async () => (await state(page)).view.quaternion).not.toEqual(focused.quaternion)
  102 |  expect((await state(page)).contacts).toEqual(initial.contacts)
  103 |  expect((await state(page)).tick).toBe(300)
  104 |  await info.attach('telescope.png', { body: await page.screenshot(), contentType: 'image/png' })
  105 |  await info.attach('measurements.json', { body: JSON.stringify({ initial, motion, moved: await state(page), repeat: 'byte-identical', translated: 'byte-identical' }, null, 2), contentType: 'application/json' })
  106 | })
  107 | 
  108 | test('SENSOR-3 adversarial optical leak and stale marker click-through', async ({ page }, info) => {
  109 |  await boot(page)
  110 |  await expect(sceneMarkers(page), 'UNSCANNED_OPTICAL_MARKER_LEAK').toHaveCount(0)
  111 |  await page.locator('canvas').click({ position: { x: 480, y: 300 } })
  112 |  expect((await state(page)).selected, 'OPTICAL_SELECTION_LEAK').toBeNull()
  113 |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  114 |  await expect(sceneMarkers(page)).toHaveCount(3)
  115 |  const planet = page.getByRole('button', { name: 'Sensor contact Detected planet', exact: true })
  116 |  await planet.click()
  117 |  expect((await state(page)).selected).toBe('planet')
  118 |  for (const hidden of ['hidden', 'back', 'outside']) {
  119 |   await expect(page.getByRole('button', { name: `Sensor contact Detected ${hidden}`, exact: true })).toHaveCount(0)
  120 |  }
  121 |  const detached = await planet.elementHandle()
  122 |  await page.getByRole('button', { name: 'Leave range', exact: true }).click()
  123 |  await expect(sceneMarkers(page)).toHaveCount(0)
  124 |  // A captured pointer target must not resurrect a stale or occluded contact.
  125 |  await detached!.evaluate(el => el.dispatchEvent(new MouseEvent('click', { bubbles: true })))
  126 |  await expect(page.getByRole('button', { name: 'Set direction', exact: true })).toHaveCount(0)
  127 |  expect((await state(page)).selected).toBeNull()
  128 |  expect((await state(page)).actions).toBe(0)
  129 |  await info.attach('adversarial.json', { body: JSON.stringify(await state(page)), contentType: 'application/json' })
  130 | })
  131 | 
  132 | test('SENSOR-4 telescope high-frequency input at huge origin preserves depth and authority', async ({ page }, info) => {
  133 |  test.setTimeout(180000)
  134 |  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message))
  135 |  await page.clock.install({ time: new Date('2026-11-06T12:00:00Z') })
  136 |  await page.clock.pauseAt(new Date('2026-11-06T12:00:01Z'))
  137 |  await page.goto('/tests/perspective.html?low-resolution&translated')
  138 |  await expect.poll(async () => { await page.clock.runFor(32); return (await state(page))?.renderer }).toContain('SwiftShader')
  139 |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await page.clock.runFor(32)
  140 |  await page.getByRole('button', { name: 'Telescope', exact: true }).click(); await page.clock.runFor(32)
  141 |  await page.locator('canvas').focus()
  142 |  const initial = await state(page), samples = []
  143 |  expect(initial.view.fov).toBe(0.1)
  144 |  const first = await page.locator('canvas').screenshot()
  145 |  // 120 browser pointer/wheel events over 60 completed frames. Each pair returns
  146 |  // to the same pose/FOV: every rendered sample must retain the tiny target.
  147 |  for (let i = 0; i < 30; i++) {
  148 |   await page.locator('canvas').dispatchEvent('wheel', { deltaY: 10, bubbles: true, cancelable: true })
  149 |   await page.locator('canvas').dispatchEvent('wheel', { deltaY: -10, bubbles: true, cancelable: true })
  150 |   await page.keyboard.down('KeyD'); await page.clock.runFor(16); await page.keyboard.up('KeyD')
  151 |   await page.keyboard.down('KeyA'); await page.clock.runFor(16); await page.keyboard.up('KeyA')
  152 |   const next = await state(page)
  153 |   expect(next.view.fov).toBeCloseTo(0.1, 12)
  154 |   expect(next.view.quaternion.every(Number.isFinite)).toBe(true)
  155 |   expect(next.markers).toHaveLength(1)
  156 |   expect(next.markers[0].ids).toEqual(['tiny'])
  157 |   expect(next.markers[0].x).toBeCloseTo(initial.markers[0].x, 7)
  158 |   expect(next.markers[0].y).toBeCloseTo(initial.markers[0].y, 7)
  159 |   expect(next.contacts).toEqual(initial.contacts); expect(next.tick).toBe(initial.tick)
  160 |   samples.push(next)
  161 |  }
  162 |  const final = await page.locator('canvas').screenshot()
> 163 |  expect(final.equals(first)).toBe(true)
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  164 |  expect(errors).toEqual([])
  165 |  await info.attach('stress-original.png', { body: first, contentType: 'image/png' })
  166 |  await info.attach('stress-final.png', { body: final, contentType: 'image/png' })
  167 |  await info.attach('stress.json', { body: JSON.stringify({ initial, samples, errors, input: 'Playwright keyboard and synthetic DOM wheel; no physical input or FPS claim' }), contentType: 'application/json' })
  168 | })
  169 | 
```