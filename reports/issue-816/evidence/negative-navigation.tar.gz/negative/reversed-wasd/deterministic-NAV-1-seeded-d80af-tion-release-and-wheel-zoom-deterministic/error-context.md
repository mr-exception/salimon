# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: deterministic.spec.ts >> NAV-1 seeded replay: exact WASD direction, release and wheel zoom
- Location: tests/deterministic.spec.ts:4:1

# Error details

```
Error: NAV-1 a moves the correct screen direction

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   -8.577319587628864
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region "Navigation radar" [ref=e4]:
    - img "Ship-centered three-dimensional radar" [ref=e7]
    - generic: SALIMON 3D HOLOGRAPHIC RADAR / SAMPLE UNIVERSE
    - img "Ship heading and velocity vector lines"
    - generic: "HEADING STATIONARY · Scanner 100,000 light-seconds · pulse #1"
  - complementary [ref=e8]:
    - heading "NAVIGATION" [level=1] [ref=e9]
    - paragraph [ref=e10]: Navigation-only prototype · unlimited energy
    - status [ref=e11]: "Scanner pulse 1: 4 temporary contacts"
    - generic [ref=e12]:
      - generic [ref=e13]: Total ship mass
      - strong [ref=e14]: 100,000 kg
    - generic [ref=e15]:
      - generic [ref=e16]: Relative position
      - strong [ref=e17]: 0.0 / 0.0 / 0.0 m (cell local)
    - generic [ref=e18]:
      - generic [ref=e19]: Speed (sample inertial frame)
      - strong [ref=e20]: 0.0 m/s
    - generic [ref=e21]:
      - generic [ref=e22]: Yaw / pitch
      - strong [ref=e23]: "-90.0° / 0.0°"
    - generic [ref=e24]:
      - generic [ref=e25]: Alignment
      - strong [ref=e26]: Manual
    - generic [ref=e27]:
      - generic [ref=e28]: Flight status
      - strong [ref=e29]: flying
    - status "Navigation warnings" [ref=e30]:
      - paragraph [ref=e31]: No navigation warnings
    - separator [ref=e32]
    - heading "Contact" [level=2] [ref=e33]
    - status [ref=e34]: No selected target
    - generic [ref=e35]: Find scanned contacts
    - searchbox "Find scanned contacts" [ref=e36]
    - generic [ref=e37]: Scanned contacts (4)
    - combobox "Scanned contacts (4)" [ref=e38]:
      - option "Choose a contact" [selected]
      - option "asteroid"
      - option "moon"
      - option "planet"
      - option "star"
    - paragraph [ref=e39]: Select a visible contact or use the scanned-contact list.
    - separator [ref=e40]
    - heading "Camera and orientation" [level=2] [ref=e41]
    - paragraph [ref=e42]: WASD pans the view · wheel zooms · arrow keys turn the ship.
    - generic [ref=e43]:
      - button "Help" [ref=e44] [cursor=pointer]
      - button "Reset camera" [ref=e45] [cursor=pointer]
    - separator [ref=e46]
    - heading "Throttle 0%" [level=2] [ref=e47]:
      - generic [ref=e48]: Throttle
      - strong [ref=e49]: 0%
    - slider "Throttle" [ref=e50]: "0"
    - button "Zero throttle (Space)" [ref=e51] [cursor=pointer]
    - paragraph [ref=e52]: Illustrative universe · unlimited energy. Impacts at 100 m/s or faster end the run. Lower-speed contact settles the ship.
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test'
  2   | import {boot,snapshot,vectors,evidence,json} from './deterministic'
  3   | 
  4   | test('NAV-1 seeded replay: exact WASD direction, release and wheel zoom',async({page},info)=>{
  5   |  const replays=[]
  6   |  for(let replay=0;replay<2;replay++) {
  7   |   await boot(page,'scenario=seeded&seed=750&view=front&vector=zero')
  8   |   const start=await snapshot(page),samples=[]
  9   |   await expect(page.getByRole('button',{name:/^(Pitch up|Pitch down|Yaw left|Yaw right|Zoom in|Zoom out)$/})).toHaveCount(0)
  10  |   for(const [key,axis,sign] of [['w',1,1],['s',1,-1],['a',0,1],['d',0,-1]] as const) {
  11  |    const before=await snapshot(page)
  12  |    await page.keyboard.down(key);await page.clock.runFor(160);await page.keyboard.up(key)
  13  |    const after=await snapshot(page)
> 14  |    expect((after.origin[axis]-before.origin[axis])*sign,`NAV-1 ${key} moves the correct screen direction`).toBeGreaterThan(1)
      |                                                                                                            ^ Error: NAV-1 a moves the correct screen direction
  15  |    expect(after.navigation.ship.yaw).toBe(start.navigation.ship.yaw)
  16  |    expect(after.navigation.ship.pitch).toBe(start.navigation.ship.pitch)
  17  |    expect(after.navigation.ship.velocityMps).toEqual(start.navigation.ship.velocityMps)
  18  |    expect(after.navigation.ship.position).toEqual(start.navigation.ship.position)
  19  |    await page.clock.runFor(32)
  20  |    expect((await snapshot(page)).origin,'NAV-1 release stops pan').toEqual(after.origin)
  21  |    samples.push({key,origin:after.origin})
  22  |   }
  23  |   await page.mouse.move(400,350)
  24  |   await page.mouse.wheel(0,-400);await page.clock.runFor(160)
  25  |   const zoomed=await snapshot(page)
  26  |   expect(zoomed.scene.zoom,'NAV-1 wheel up zooms in').toBeGreaterThan(start.scene.zoom)
  27  |   await page.mouse.wheel(0,400);await page.clock.runFor(160)
  28  |   expect((await snapshot(page)).scene.zoom).toBeCloseTo(start.scene.zoom,10)
  29  |   // 4*(160+32)+2*160 = 1088ms straddles a fractional 60Hz tick.
  30  |   // Complete 1200ms (75 RAF intervals / 72 fixed ticks) before comparing replays.
  31  |   await page.clock.runFor(112)
  32  |   const ticks=(await snapshot(page)).navigation.ship.tick-start.navigation.ship.tick
  33  |   expect(ticks,'NAV-1 replay covers 72 complete fixed ticks').toBe(72)
  34  |   replays.push({catalog:start.navigation.catalog,samples,zoom:zoomed.scene.zoom,ticks})
  35  |  }
  36  |  expect(replays[1],'NAV-1 identical seed and input clock replay').toEqual(replays[0])
  37  |  await evidence(page,info,'seeded-replay',replays)
  38  |  await boot(page,'scenario=seeded&seed=751&view=front&vector=zero')
  39  |  expect((await snapshot(page)).navigation.catalog).not.toEqual(replays[0].catalog)
  40  | })
  41  | 
  42  | test('NAV-2 fixed-clock scan: no discovery before tick 300, stable selection during continuous pan',async({page},info)=>{
  43  |  await boot(page,'scenario=seeded-empty&seed=750&view=front&vector=zero')
  44  |  await expect(page.locator('.scan-status')).toContainText('awaiting first')
  45  |  expect((await snapshot(page)).navigation.pulse).toBe(0)
  46  |  // Tick is authoritative: stop short of the first pulse, then cross it.
  47  |  while((await snapshot(page)).navigation.ship.tick<295)await page.clock.runFor(16)
  48  |  expect((await snapshot(page)).navigation.pulse).toBe(0)
  49  |  await expect(page.locator('#contact-select option')).toHaveCount(1)
  50  |  await page.clock.runFor(160)
  51  |  await expect(page.locator('.scan-status')).toContainText('4 temporary contacts')
  52  |  await page.getByLabel('Scanned contacts (4)',{exact:true}).selectOption('planet')
  53  |  await page.getByRole('region',{name:'Navigation radar',exact:true}).focus()
  54  |  const recordings=[]
  55  |  for(const input of ['keyboard','mouse']) {
  56  |   const recording=page.evaluate(()=>window.radarTest.recordFrames(20))
  57  |   if(input==='keyboard')await page.keyboard.down('d')
  58  |   else {await page.mouse.move(500,350);await page.mouse.down({button:'right'});await page.mouse.move(540,360,{steps:4})}
  59  |   await page.clock.runFor(400)
  60  |   const data=await recording
  61  |   if(input==='keyboard')await page.keyboard.up('d');else await page.mouse.up({button:'right'})
  62  |   const bodies=data.frames.flatMap(f=>f.bodies)
  63  |   expect(bodies.length,'NAV-2 nonvacuous in-view body evidence').toBeGreaterThan(20)
  64  |   expect(bodies.every(b=>b.present&&b.bright>=10),'NAV-2 bodies remain rendered during pan').toBe(true)
  65  |   for(const b of bodies){expect(b.actualPixel![0]).toBeCloseTo(b.pixel[0],5);expect(b.actualPixel![1]).toBeCloseTo(b.pixel[1],5)}
  66  |   expect(data.frames.every(f=>f.ship!==null)).toBe(true)
  67  |   for(const frame of data.frames) {
  68  |    const heading=frame.vectors.find(v=>v.kind==='heading')!
  69  |    expect(heading.display,'NAV-2 heading remains visible every frame').not.toBe('none')
  70  |    expect(heading.start[0]).toBeCloseTo(frame.ship![0]/970*100,5)
  71  |    expect(heading.start[1]).toBeCloseTo(frame.ship![1]/800*100,5)
  72  |    expect(heading.end[0]).toBe(100)
  73  |    expect(heading.end[1]).toBeCloseTo(heading.start[1],5)
  74  |   }
  75  |   expect((await snapshot(page)).navigation.selected).toBe('planet')
  76  |   for(const [kind,url] of Object.entries(data.captures))await info.attach(`${input}-${kind}.png`,{body:Buffer.from(url.split(',')[1],'base64'),contentType:'image/png'})
  77  |   recordings.push({input,frames:data.frames,renderer:data.renderer})
  78  |  }
  79  |  await evidence(page,info,'continuous-pan',recordings)
  80  | })
  81  | 
  82  | test('NAV-3 heading and velocity retain approved colors and viewport edges',async({page},info)=>{
  83  |  await boot(page)
  84  |  const lines=await vectors(page)
  85  |  expect(lines.map(l=>l.kind)).toEqual(['heading','velocity'])
  86  |  expect(lines[0].stroke,'NAV-3 heading is yellow').toBe('rgb(255, 227, 106)')
  87  |  expect(lines[1].stroke,'NAV-3 velocity is light-green').toBe('rgb(182, 245, 162)')
  88  |  expect(lines[1].dash).not.toBe('none')
  89  |  expect(lines[0].end[0]).toBe(100);expect(lines[1].end[1]).toBe(0)
  90  |  await expect(page.locator('.direction-lines,[data-offscreen],[marker-start],[marker-end]')).toHaveCount(0)
  91  |  expect((await snapshot(page)).scene.arrows).toBe(0)
  92  |  for(const line of lines){expect(line.start).toEqual([50,50]);expect([...line.start,...line.end].every(n=>Number.isFinite(n)&&n>=0&&n<=100)).toBe(true)}
  93  |  await evidence(page,info,'different-vectors',{lines,state:await snapshot(page)})
  94  |  await boot(page,'scenario=seeded&seed=750&view=front&vector=zero')
  95  |  expect((await vectors(page)).map(l=>l.kind)).toEqual(['heading'])
  96  |  await evidence(page,info,'stationary',{lines:await vectors(page),state:await snapshot(page)})
  97  | })
  98  | 
  99  | test('NAV-4 read-only fixture observers return detached state; production has no hooks',async({page,request},info)=>{
  100 |  await boot(page)
  101 |  const before=await snapshot(page)
  102 |  const keys=await page.evaluate(()=>{
  103 |   const state=window.navigationTest.snapshot();Object.assign(state.ship.velocityMps,{0:999});state.catalog.length=0
  104 |   const scene=window.radarTest.snapshot();scene.objects.length=0
  105 |   return {navigation:Object.keys(window.navigationTest),radar:Object.keys(window.radarTest)}
  106 |  })
  107 |  expect(await snapshot(page)).toEqual(before)
  108 |  expect(keys.navigation.sort()).toEqual(['positions','snapshot'])
  109 |  expect(keys.radar.sort()).toEqual(['projectLs','recordFrames','snapshot'])
  110 |  await info.attach('observer-contract.json',{body:json(keys),contentType:'application/json'})
  111 |  await page.goto('http://127.0.0.1:4175/?scene=radar')
  112 |  await expect(page.locator('canvas')).toBeVisible()
  113 |  expect(await page.evaluate(()=>({navigation:'navigationTest' in window,radar:'radarTest' in window}))).toEqual({navigation:false,radar:false})
  114 |  const response=await request.get('http://127.0.0.1:4175/tests/fixture.html')
```