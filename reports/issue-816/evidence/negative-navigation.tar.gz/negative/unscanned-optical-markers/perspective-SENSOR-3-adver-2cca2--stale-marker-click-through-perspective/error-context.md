# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: perspective.spec.ts >> SENSOR-3 adversarial optical leak and stale marker click-through
- Location: tests/perspective.spec.ts:108:1

# Error details

```
Error: UNSCANNED_OPTICAL_MARKER_LEAK

expect(locator).toHaveCount(expected) failed

Locator:  getByRole('button', { name: /^Sensor contact / })
Expected: 0
Received: 3
Timeout:  10000ms

Call log:
  - UNSCANNED_OPTICAL_MARKER_LEAK getByRole('button', { name: /^Sensor contact / }) with timeout 10000ms
  - waiting for getByRole('button', { name: /^Sensor contact / })
    9 × locator resolved to 3 elements
      - unexpected value "3"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic:
      - button "Sensor contact group of 18" [ref=e7]: "18"
      - button "Sensor contact undefined" [ref=e8]: +
      - button "Sensor contact undefined" [ref=e9]: +
      - region "Detected contacts" [ref=e10]:
        - group [ref=e11]:
          - generic "Observation help" [ref=e12]
        - generic [ref=e13]:
          - generic [ref=e14]:
            - text: Search contacts
            - textbox "Search contacts" [ref=e15]
          - list
          - button "Previous" [disabled] [ref=e16]
          - generic [ref=e17]: 1/1
          - button "Next" [disabled] [ref=e18]
        - status [ref=e20]: No selection
  - navigation [ref=e21]:
    - button "Tick" [ref=e22]
    - button "Pulse" [ref=e23]
    - button "Leave range" [ref=e24]
    - button "Telescope" [ref=e25]
    - button "Reset view" [ref=e26]
```

# Test source

```ts
  10  | test('SENSOR-1 scanner authority, hidden/browser contacts, group pagination and eviction', async ({ page }, info) => {
  11  |  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message))
  12  |  await boot(page)
  13  |  expect((await state(page)).contacts).toEqual([])
  14  |  await expect(sceneMarkers(page)).toHaveCount(0)
  15  |  await expect(page.getByText('Detected planet', { exact: true })).toHaveCount(0)
  16  |  // The visible optical globe has no discovery target before the pulse.
  17  |  await page.locator('canvas').click({ position: { x: 480, y: 300 } })
  18  |  expect((await state(page)).selected).toBeNull()
  19  |  const before = await page.screenshot()
  20  |  const png = PNG.sync.read(before), center = (300 * png.width + 480) * 4
  21  |  expect(png.data[center] + png.data[center + 1] + png.data[center + 2]).toBeGreaterThan(10)
  22  |  await info.attach('before-pulse.png', { body: before, contentType: 'image/png' })
  23  |  await page.getByRole('button', { name: 'Tick', exact: true }).click()
  24  |  await expect(sceneMarkers(page)).toHaveCount(0)
  25  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  26  |  await expect(sceneMarkers(page)).toHaveCount(3)
  27  |  const scanned = await state(page)
  28  |  expect(scanned.contacts).toHaveLength(23)
  29  |  expect(scanned.markers.flatMap(m => m.ids).sort()).toEqual(['planet', 'tiny', ...Array.from({ length: 18 }, (_, i) => `dense-${String(i).padStart(2, '0')}`)].sort())
  30  |  await info.attach('scanned.png', { body: await page.screenshot(), contentType: 'image/png' })
  31  |  await page.getByRole('button', { name: 'Sensor contact Detected tiny', exact: true }).click()
  32  |  await expect(page.getByRole('status')).toHaveText('Selected: Detected tiny')
  33  |  for (const id of ['hidden', 'back', 'outside']) {
  34  |   await page.getByRole('textbox').fill(id)
  35  |   await page.getByRole('button', { name: `Detected ${id}`, exact: true }).click()
  36  |   await expect(page.getByRole('status')).toHaveText(`Selected: Detected ${id}`)
  37  |  }
  38  |  await page.getByRole('button', { name: 'Set direction', exact: true }).click()
  39  |  await expect.poll(async () => (await state(page)).actions).toBe(1)
  40  |  await page.getByRole('textbox').fill('')
  41  |  await page.getByRole('button', { name: 'Sensor contact group of 18', exact: true }).click()
  42  |  const ids: string[] = []
  43  |  for (let i = 0; i < 3; i++) {
  44  |   const buttons = page.getByRole('region', { name: 'Detected contacts' }).locator('li button')
  45  |   ids.push(...await buttons.allTextContents())
  46  |   await buttons.last().click()
  47  |   if (i < 2) await page.getByRole('button', { name: 'Next', exact: true }).click()
  48  |  }
  49  |  expect(ids).toHaveLength(18); expect(new Set(ids).size).toBe(18)
  50  |  await expect(page.getByRole('button', { name: 'Next', exact: true })).toBeDisabled()
  51  |  await page.getByRole('button', { name: 'All contacts', exact: true }).click()
  52  |  await page.getByRole('textbox').fill('tiny')
  53  |  await page.getByRole('button', { name: 'Detected tiny', exact: true }).click()
  54  |  await page.getByRole('button', { name: 'Telescope', exact: true }).click()
  55  |  await expect(sceneMarkers(page)).toHaveCount(1)
  56  |  await page.getByRole('button', { name: 'Sensor contact Detected tiny', exact: true }).click()
  57  |  await info.attach('tiny-telescope.png', { body: await page.screenshot(), contentType: 'image/png' })
  58  |  await expect(page.getByRole('status')).toHaveText('Selected: Detected tiny')
  59  |  await page.getByRole('button', { name: 'Leave range', exact: true }).click()
  60  |  await expect(page.getByRole('status')).toHaveText('No selection')
  61  |  await expect(page.getByRole('button', { name: 'Set direction', exact: true })).toHaveCount(0)
  62  |  await expect(sceneMarkers(page)).toHaveCount(0)
  63  |  expect((await state(page)).selected).toBeNull()
  64  |  expect((await state(page)).contacts).toEqual([])
  65  |  expect(errors).toEqual([])
  66  |  await info.attach('measurements.json', { body: JSON.stringify({ scanned, groupIds: ids, evicted: await state(page), errors }, null, 2), contentType: 'application/json' })
  67  | })
  68  | test('SENSOR-2 repeat/translated pixels, telescope motion and stale group suppression', async ({ page }, info) => {
  69  |  await boot(page)
  70  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  71  |  await expect(sceneMarkers(page)).toHaveCount(3)
  72  |  // Blur Pulse so focus decorations cannot differ between captures.
  73  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  74  |  const first = await page.screenshot(), initial = await state(page)
  75  |  expect((await page.screenshot()).equals(first)).toBe(true)
  76  |  await boot(page, true)
  77  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  78  |  await expect(sceneMarkers(page)).toHaveCount(3)
  79  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  80  |  expect((await page.screenshot()).equals(first)).toBe(true)
  81  |  expect((await state(page)).markers).toEqual(initial.markers)
  82  |  await page.getByRole('button', { name: 'Sensor contact group of 18', exact: true }).click()
  83  |  await page.getByRole('button', { name: 'Telescope', exact: true }).click()
  84  |  await expect(page.getByText('Group no longer visible')).toBeVisible()
  85  |  await expect(page.getByRole('region', { name: 'Detected contacts' }).locator('li button')).toHaveCount(0)
  86  |  await page.getByRole('button', { name: 'All contacts', exact: true }).click()
  87  |  await page.getByRole('textbox').fill('back')
  88  |  await page.keyboard.press('KeyD')
  89  |  const focused = (await state(page)).view
  90  |  await page.keyboard.down('KeyD'); await page.waitForTimeout(100); await page.keyboard.up('KeyD')
  91  |  expect((await state(page)).view).toEqual(focused)
  92  |  await page.locator('canvas').click({ position: { x: 50, y: 550 } })
  93  |  await page.keyboard.down('KeyD')
  94  |  const motion = await page.evaluate(async () => {
  95  |   const samples: (State & { domMarkers: number })[] = []
  96  |   for (let i = 0; i < 6; i++) { await new Promise(requestAnimationFrame); samples.push({ ...(window as unknown as { sensorSnapshot(): State }).sensorSnapshot(), domMarkers: document.querySelectorAll('button[aria-label^="Sensor contact "]').length }) }
  97  |   return samples
  98  |  })
  99  |  await page.keyboard.up('KeyD')
  100 |  expect(motion.every(s => s.domMarkers === 1 && s.markers.length === 1 && s.markers.every(m => Number.isFinite(m.x) && Number.isFinite(m.y)))).toBe(true)
  101 |  await expect.poll(async () => (await state(page)).view.quaternion).not.toEqual(focused.quaternion)
  102 |  expect((await state(page)).contacts).toEqual(initial.contacts)
  103 |  expect((await state(page)).tick).toBe(300)
  104 |  await info.attach('telescope.png', { body: await page.screenshot(), contentType: 'image/png' })
  105 |  await info.attach('measurements.json', { body: JSON.stringify({ initial, motion, moved: await state(page), repeat: 'byte-identical', translated: 'byte-identical' }, null, 2), contentType: 'application/json' })
  106 | })
  107 | 
  108 | test('SENSOR-3 adversarial optical leak and stale marker click-through', async ({ page }, info) => {
  109 |  await boot(page)
> 110 |  await expect(sceneMarkers(page), 'UNSCANNED_OPTICAL_MARKER_LEAK').toHaveCount(0)
      |                                                                    ^ Error: UNSCANNED_OPTICAL_MARKER_LEAK
  111 |  await page.locator('canvas').click({ position: { x: 480, y: 300 } })
  112 |  expect((await state(page)).selected, 'OPTICAL_SELECTION_LEAK').toBeNull()
  113 |  await page.getByRole('button', { name: 'Pulse', exact: true }).click()
  114 |  await expect(sceneMarkers(page)).toHaveCount(3)
  115 |  const planet = page.getByRole('button', { name: 'Sensor contact Detected planet', exact: true })
  116 |  await planet.click()
  117 |  expect((await state(page)).selected).toBe('planet')
  118 |  for (const hidden of ['hidden', 'back', 'outside']) {
  119 |   await expect(page.getByRole('button', { name: `Sensor contact Detected ${hidden}`, exact: true })).toHaveCount(0)
  120 |  }
  121 |  const detached = await planet.elementHandle()
  122 |  await page.getByRole('button', { name: 'Leave range', exact: true }).click()
  123 |  await expect(sceneMarkers(page)).toHaveCount(0)
  124 |  // A captured pointer target must not resurrect a stale or occluded contact.
  125 |  await detached!.evaluate(el => el.dispatchEvent(new MouseEvent('click', { bubbles: true })))
  126 |  await expect(page.getByRole('button', { name: 'Set direction', exact: true })).toHaveCount(0)
  127 |  expect((await state(page)).selected).toBeNull()
  128 |  expect((await state(page)).actions).toBe(0)
  129 |  await info.attach('adversarial.json', { body: JSON.stringify(await state(page)), contentType: 'application/json' })
  130 | })
  131 | 
  132 | test('SENSOR-4 telescope high-frequency input at huge origin preserves depth and authority', async ({ page }, info) => {
  133 |  test.setTimeout(180000)
  134 |  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message))
  135 |  await page.clock.install({ time: new Date('2026-11-06T12:00:00Z') })
  136 |  await page.clock.pauseAt(new Date('2026-11-06T12:00:01Z'))
  137 |  await page.goto('/tests/perspective.html?low-resolution&translated&stress')
  138 |  await expect.poll(async () => { await page.clock.runFor(32); return (await state(page))?.renderer }).toContain('SwiftShader')
  139 |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await page.clock.runFor(32)
  140 |  await page.getByRole('button', { name: 'Telescope', exact: true }).click(); await page.clock.runFor(32)
  141 |  await page.locator('canvas').focus()
  142 |  await page.keyboard.press('Shift') // Match keyboard focus-visible decoration in both originals.
  143 |  await page.clock.runFor(32)
  144 |  const initial = await state(page)
  145 |  const samples: { phase: string; state: State }[] = []
  146 |  expect(initial.view.fov).toBe(0.1)
  147 |  const first = await page.locator('canvas').screenshot()
  148 |  expect(initial.origin.cell).toEqual([(10n ** 24n).toString(), (-(10n ** 24n)).toString(), (10n ** 30n).toString()])
  149 |  const observe = (phase: string, next: State) => {
  150 |   expect(next.view.quaternion.every(Number.isFinite)).toBe(true)
  151 |   expect(Math.hypot(...next.view.quaternion)).toBeCloseTo(1, 12)
  152 |   expect(next.render.fov).toBeCloseTo(next.view.fov, 12)
  153 |   expect(next.markers).toHaveLength(1); expect(next.markers[0].ids).toEqual(['tiny'])
  154 |   expect(next.markers.every(m => Number.isFinite(m.x) && Number.isFinite(m.y))).toBe(true)
  155 |   expect(next.render.pixels!.error).toBe(0)
  156 |   expect(next.render.pixels!.peakLuma, 'OPTICAL_GPU_BLANK_FRAME').toBeGreaterThan(10)
  157 |   expect(next.render.pixels!.litPixels).toBeGreaterThan(0)
  158 |   expect(next.contacts).toEqual(initial.contacts); expect(next.tick).toBe(initial.tick)
  159 |   expect(next.origin).toEqual(initial.origin); expect(next.actions).toBe(0)
  160 |   samples.push({ phase, state: next })
  161 |  }
  162 |  // Render both zoom states; never reverse a zoom before its frame is observed.
  163 |  // The readback observes the previous completed frame, covering each phase.
  164 |  for (let i = 0; i < 30; i++) {
  165 |   await page.locator('canvas').dispatchEvent('wheel', { deltaY: 10, bubbles: true, cancelable: true })
  166 |   await page.keyboard.down('KeyD'); await page.clock.runFor(16); await page.keyboard.up('KeyD')
  167 |   const right = await state(page); expect(right.render.fov).toBeGreaterThan(0.1); observe('right-zoomed', right)
  168 |   expect(Math.abs(right.markers[0].x - initial.markers[0].x), 'STRESS_MOVEMENT_NONVACUOUS').toBeGreaterThan(0.5)
  169 |   await page.keyboard.down('KeyA'); await page.clock.runFor(16); await page.keyboard.up('KeyA')
  170 |   observe('left-zoomed', await state(page))
  171 |   await page.locator('canvas').dispatchEvent('wheel', { deltaY: -10, bubbles: true, cancelable: true })
  172 |   await page.clock.runFor(16)
  173 |   const next = await state(page); observe('telescope', next)
  174 |   expect(next.view.fov).toBeCloseTo(0.1, 12)
  175 |   expect(next.markers[0].x).toBeCloseTo(initial.markers[0].x, 7)
  176 |   expect(next.markers[0].y).toBeCloseTo(initial.markers[0].y, 7)
  177 |  }
  178 |  expect(new Set(samples.map(s => s.state.render.pixels!.frame)).size).toBe(90)
  179 |  await page.clock.runFor(32)
  180 |  const final = await page.locator('canvas').screenshot()
  181 |  await info.attach('stress-original.png', { body: first, contentType: 'image/png' })
  182 |  await info.attach('stress-final.png', { body: final, contentType: 'image/png' })
  183 |  await info.attach('stress.json', { body: JSON.stringify({ initial, final: await state(page), samples, errors, fixture: { targetRadiusM: 1, wheelEvents: 60, heldKeyIntervals: 60, requestedIntervalMs: 16 }, input: 'Playwright keyboard and synthetic DOM wheel; no physical input or FPS claim' }), contentType: 'application/json' })
  184 |  expect(final.equals(first), 'STRESS_REPEAT_PIXELS').toBe(true)
  185 |  expect(errors).toEqual([])
  186 | })
  187 | 
```