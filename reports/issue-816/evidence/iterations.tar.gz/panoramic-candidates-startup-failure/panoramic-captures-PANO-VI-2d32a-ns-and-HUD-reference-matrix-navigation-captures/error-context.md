# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: panoramic-captures.spec.ts >> PANO-VIS panoramic optical, sensor, actions and HUD reference matrix
- Location: tests/panoramic-captures.spec.ts:15:1

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:5175/tests/optical.html?scenario=telescope
Call log:
  - navigating to "http://127.0.0.1:5175/tests/optical.html?scenario=telescope", waiting until "load"

```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test'
  2   | import { readFile, writeFile, mkdir } from 'node:fs/promises'
  3   | import { execFileSync } from 'node:child_process'
  4   | import { compareImages, POLICY, sha256 } from '../scripts/visual-comparison.ts'
  5   | 
  6   | const directory = 'tests/navigation-baselines'
  7   | const candidate = process.env.SALIMON_PANORAMIC_CANDIDATES === '1'
  8   | if (candidate && process.env.CI) throw Error('Candidate generation is forbidden in CI')
  9   | const json = (v: unknown) => JSON.stringify(v, (_, x) => typeof x === 'bigint' ? String(x) : x, 2)
  10  | // Observers are fixture-only, read-only snapshots of the production adapters.
  11  | async function state(page: Page, owner: string): Promise<Record<string, unknown>> {
  12  |  return page.evaluate(owner => (window as unknown as Record<string, () => Record<string, unknown>>)[`${owner}Snapshot`](), owner)
  13  | }
  14  | 
  15  | test('PANO-VIS panoramic optical, sensor, actions and HUD reference matrix', async ({ page, browser }, info) => {
  16  |  test.setTimeout(360000)
  17  |  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message))
  18  |  const source = await readFile('.revision-for-negative', 'utf8').catch(() => execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim())
  19  |  const environment = { platform: process.platform, arch: process.arch, browser: browser.version(), playwright: JSON.parse(await readFile('node_modules/@playwright/test/package.json', 'utf8')).version,
  20  |   viewport: { width: 1280, height: 800 }, dpr: 1, epoch: '2026-11-06T12:00:00.000Z', locale: 'en-US', timezone: 'UTC', policy: POLICY,
  21  |   fonts: Object.fromEntries(await Promise.all(['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf', 'fonts.css', 'fonts.conf'].map(async f => [f, sha256(await readFile(`tests/assets/${f}`))]))) }
  22  |  expect(info.project.use.launchOptions?.env?.FONTCONFIG_FILE).toMatch(/tests\/assets\/fonts\.conf$/)
  23  |  const manifest = JSON.parse(await readFile(`${directory}/manifest.json`, 'utf8'))
  24  |  if (!candidate) expect(environment, 'PANORAMIC_ENVIRONMENT_DRIFT').toEqual(manifest.panoramic.environment)
  25  |  const images: Record<string, string> = {}, results: Record<string, unknown>[] = []
  26  |  const output = info.outputPath('comparisons'); await mkdir(output, { recursive: true })
  27  |  await page.clock.install({ time: new Date(environment.epoch) })
  28  |  await page.clock.pauseAt(new Date('2026-11-06T12:00:01Z'))
  29  |  const settle = async () => { await page.clock.runFor(160) }
  30  |  const boot = async (path: string, owner: string) => {
> 31  |   await page.goto(path)
      |              ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:5175/tests/optical.html?scenario=telescope
  32  |   await expect.poll(async () => { await settle(); return (await state(page, owner))?.renderer }).toContain('SwiftShader')
  33  |   await page.evaluate(() => document.fonts.ready); await settle()
  34  |  }
  35  |  const capture = async (id: string, owner: string) => {
  36  |   await page.locator('canvas').focus(); await page.mouse.move(1279, 799); await settle()
  37  |   const snapshot = await state(page, owner)
  38  |   const actual = await page.screenshot({ caret: 'hide' }), name = `panoramic-${id}.png`
  39  |   images[name] = sha256(actual)
  40  |   await writeFile(`${output}/${name}`, actual)
  41  |   await writeFile(`${output}/panoramic-${id}.json`, json({ source, environment, snapshot, errors }))
  42  |   await info.attach(name, { body: actual, contentType: 'image/png' })
  43  |   if (candidate) { results.push({ id, status: 'CANDIDATE', sha256: images[name] }); return }
  44  |   const expected = await readFile(`${directory}/${name}`)
  45  |   expect(sha256(expected), `PANORAMIC_BASELINE_HASH ${id}`).toBe(manifest.images[name])
  46  |   const { diff, ...comparison } = compareImages(expected, actual)
  47  |   await writeFile(`${output}/${id}-diff.png`, diff)
  48  |   results.push({ id, ...comparison, expected: sha256(expected), actual: images[name] })
  49  |   expect.soft(comparison.pass, `PANORAMIC_PIXEL_MISMATCH ${id}`).toBe(true)
  50  |  }
  51  |  for (const scenario of ['wide', 'telescope', 'telescope-translated', 'translated', 'surface', 'below']) {
  52  |   await boot(`/tests/optical.html?scenario=${scenario}`, 'optical')
  53  |   expect((await state(page, 'optical')).contacts).toBe(0)
  54  |   await capture(scenario, 'optical')
  55  |  }
  56  |  await boot('/tests/perspective.html?low-resolution', 'sensor')
  57  |  expect((await state(page, 'sensor')).selected).toBeNull()
  58  |  await capture('empty-scanner', 'sensor')
  59  |  // Adversarial optical clicks must never discover or select catalog bodies.
  60  |  await page.locator('canvas').click({ position: { x: 640, y: 400 } }); await settle()
  61  |  expect((await state(page, 'sensor')).selected, 'OPTICAL_SELECTION_LEAK').toBeNull()
  62  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await settle()
  63  |  const markers = (await state(page, 'sensor')).markers as { ids: string[] }[]
  64  |  expect(markers.flatMap(m => m.ids)).not.toContain('hidden')
  65  |  expect(markers.flatMap(m => m.ids)).not.toContain('back')
  66  |  await expect(page.getByRole('button', { name: 'Sensor contact Detected hidden', exact: true })).toHaveCount(0)
  67  |  await expect(page.getByRole('button', { name: 'Sensor contact Detected back', exact: true })).toHaveCount(0)
  68  |  await capture('detected-occluded-rear', 'sensor')
  69  |  await page.getByRole('button', { name: 'Sensor contact Detected planet', exact: true }).click(); await settle()
  70  |  expect((await state(page, 'sensor')).selected).toBe('planet') // hidden center cannot intercept
  71  |  await page.getByRole('button', { name: 'Sensor contact group of 18', exact: true }).click(); await settle()
  72  |  await capture('overlap', 'sensor')
  73  |  await page.getByRole('button', { name: 'Next', exact: true }).click(); await settle()
  74  |  await capture('pagination', 'sensor')
  75  |  await page.getByRole('button', { name: 'Telescope', exact: true }).click(); await settle()
  76  |  await capture('sensor-telescope', 'sensor')
  77  |  await page.getByRole('button', { name: 'Leave range', exact: true }).click(); await settle()
  78  |  expect((await state(page, 'sensor')).selected).toBeNull()
  79  |  await expect(page.getByRole('button', { name: 'Set direction', exact: true })).toHaveCount(0)
  80  |  await capture('lost-contact', 'sensor')
  81  |  await boot('/tests/look-at.html', 'look')
  82  |  await page.getByRole('button', { name: 'Pulse', exact: true }).click(); await settle()
  83  |  await page.getByRole('textbox').fill('Behind')
  84  |  await page.getByRole('button', { name: 'Behind', exact: true }).click()
  85  |  const before = (await state(page, 'look')).ship
  86  |  await page.getByRole('button', { name: 'Look at', exact: true }).click()
  87  |  await page.clock.runFor(1200)
  88  |  expect((await state(page, 'look')).ship).toEqual(before)
  89  |  await capture('look-at-occluded', 'look')
  90  |  await page.getByRole('button', { name: 'Set direction', exact: true }).click()
  91  |  await page.clock.runFor(320)
  92  |  expect(((await state(page, 'look')).ship as { yaw: number }).yaw).not.toBe((before as { yaw: number }).yaw)
  93  |  await capture('set-direction', 'look')
  94  |  await boot('/tests/panoramic.html', 'hud')
  95  |  for (const kind of ['stationary', 'rear', 'overlap']) {
  96  |   await page.evaluate(kind => (window as unknown as { hudScenario(k: string): void }).hudScenario(kind), kind)
  97  |   await capture(`compass-${kind}`, 'hud')
  98  |  }
  99  |  await page.setViewportSize({ width: 960, height: 600 })
  100 |  await page.getByRole('button', { name: /Contacts \(C\)/ }).click()
  101 |  await page.getByRole('button', { name: 'Telemetry', exact: true }).click()
  102 |  for (const kind of ['warning', 'destroyed']) {
  103 |   await page.evaluate(kind => (window as unknown as { hudScenario(k: string): void }).hudScenario(kind), kind)
  104 |   await settle()
  105 |   expect(await page.evaluate(() => ({ w: document.documentElement.scrollWidth, h: document.documentElement.scrollHeight }))).toEqual({ w: 960, h: 600 })
  106 |   if (kind === 'destroyed') await expect(page.getByRole('button', { name: 'Restart navigation', exact: true })).toBeInViewport()
  107 |   await capture(`small-${kind}`, 'hud')
  108 |  }
  109 |  expect(errors).toEqual([])
  110 |  await writeFile(`${output}/summary.json`, json({ source, environment, candidate, results, errors }))
  111 |  await info.attach('panoramic-summary.json', { body: json({ source, environment, candidate, results, errors }), contentType: 'application/json' })
  112 |  if (candidate) {
  113 |   for (const name of Object.keys(images)) await writeFile(`${directory}/${name}`, await readFile(`${output}/${name}`))
  114 |   await writeFile(`${directory}/manifest.json`, json({ ...manifest, panoramic: { environment, status: 'AWAITING_HUMAN_REVIEW' }, images: { ...manifest.images, ...images } }) + '\n')
  115 |  }
  116 | })
  117 | 
```